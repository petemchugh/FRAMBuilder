﻿Public Class Var_and_Utils

End Class
