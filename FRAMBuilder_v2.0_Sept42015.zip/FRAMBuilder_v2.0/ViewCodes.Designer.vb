﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_ViewCodes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
Me.components = New System.ComponentModel.Container()
Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
Me.lbl_CWTdb2 = New System.Windows.Forms.Label()
Me.grd_CodeView = New System.Windows.Forms.DataGridView()
Me.btn_SelectUnselect = New System.Windows.Forms.Button()
Me.btn_Return1 = New System.Windows.Forms.Button()
Me.btn_LoadTags = New System.Windows.Forms.Button()
Me.tip_SelectUnselect = New System.Windows.Forms.ToolTip(Me.components)
Me.pb_Loading = New System.Windows.Forms.ProgressBar()
Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
Me.dom_BroodYearChoose = New System.Windows.Forms.DomainUpDown()
Me.btn_LoadCodes = New System.Windows.Forms.Button()
Me.btn_BypassView = New System.Windows.Forms.Button()
Me.lbl_queryrunning = New System.Windows.Forms.Label()
Me.ck_Bonus = New System.Windows.Forms.CheckBox()
Me.ck_Unmarked = New System.Windows.Forms.CheckBox()
CType(Me.grd_CodeView, System.ComponentModel.ISupportInitialize).BeginInit()
Me.SuspendLayout()
'
'lbl_CWTdb2
'
Me.lbl_CWTdb2.AutoSize = True
Me.lbl_CWTdb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.lbl_CWTdb2.Location = New System.Drawing.Point(16, 725)
Me.lbl_CWTdb2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
Me.lbl_CWTdb2.Name = "lbl_CWTdb2"
Me.lbl_CWTdb2.Size = New System.Drawing.Size(186, 18)
Me.lbl_CWTdb2.TabIndex = 2
Me.lbl_CWTdb2.Text = "Database: (None Selected)"
'
'grd_CodeView
'
Me.grd_CodeView.AllowUserToOrderColumns = True
DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
Me.grd_CodeView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
Me.grd_CodeView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
Me.grd_CodeView.DefaultCellStyle = DataGridViewCellStyle8
Me.grd_CodeView.Location = New System.Drawing.Point(16, 60)
Me.grd_CodeView.Margin = New System.Windows.Forms.Padding(4)
Me.grd_CodeView.Name = "grd_CodeView"
DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
Me.grd_CodeView.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
Me.grd_CodeView.Size = New System.Drawing.Size(1429, 528)
Me.grd_CodeView.TabIndex = 3
'
'btn_SelectUnselect
'
Me.btn_SelectUnselect.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.btn_SelectUnselect.Location = New System.Drawing.Point(687, 631)
Me.btn_SelectUnselect.Margin = New System.Windows.Forms.Padding(4)
Me.btn_SelectUnselect.Name = "btn_SelectUnselect"
Me.btn_SelectUnselect.Size = New System.Drawing.Size(156, 71)
Me.btn_SelectUnselect.TabIndex = 4
Me.btn_SelectUnselect.Text = "Select or Unselect All"
Me.btn_SelectUnselect.UseVisualStyleBackColor = True
'
'btn_Return1
'
Me.btn_Return1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
Me.btn_Return1.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.btn_Return1.Location = New System.Drawing.Point(1225, 631)
Me.btn_Return1.Margin = New System.Windows.Forms.Padding(4)
Me.btn_Return1.Name = "btn_Return1"
Me.btn_Return1.Size = New System.Drawing.Size(187, 71)
Me.btn_Return1.TabIndex = 5
Me.btn_Return1.Text = "Return To Main Menu"
Me.btn_Return1.UseVisualStyleBackColor = False
'
'btn_LoadTags
'
Me.btn_LoadTags.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.btn_LoadTags.Location = New System.Drawing.Point(859, 631)
Me.btn_LoadTags.Margin = New System.Windows.Forms.Padding(4)
Me.btn_LoadTags.Name = "btn_LoadTags"
Me.btn_LoadTags.Size = New System.Drawing.Size(160, 71)
Me.btn_LoadTags.TabIndex = 6
Me.btn_LoadTags.Text = "Import and View (SLOW)"
Me.btn_LoadTags.UseVisualStyleBackColor = True
'
'pb_Loading
'
Me.pb_Loading.Location = New System.Drawing.Point(21, 645)
Me.pb_Loading.Margin = New System.Windows.Forms.Padding(4)
Me.pb_Loading.MarqueeAnimationSpeed = 1
Me.pb_Loading.Maximum = 1000
Me.pb_Loading.Name = "pb_Loading"
Me.pb_Loading.Size = New System.Drawing.Size(644, 64)
Me.pb_Loading.Step = 1
Me.pb_Loading.Style = System.Windows.Forms.ProgressBarStyle.Marquee
Me.pb_Loading.TabIndex = 7
'
'BackgroundWorker1
'
'
'dom_BroodYearChoose
'
Me.dom_BroodYearChoose.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.dom_BroodYearChoose.Location = New System.Drawing.Point(21, 12)
Me.dom_BroodYearChoose.Margin = New System.Windows.Forms.Padding(4)
Me.dom_BroodYearChoose.Name = "dom_BroodYearChoose"
Me.dom_BroodYearChoose.Size = New System.Drawing.Size(319, 36)
Me.dom_BroodYearChoose.TabIndex = 9
Me.dom_BroodYearChoose.Text = "(Choose Brood Year)"
'
'btn_LoadCodes
'
Me.btn_LoadCodes.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
Me.btn_LoadCodes.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.btn_LoadCodes.Location = New System.Drawing.Point(364, 12)
Me.btn_LoadCodes.Margin = New System.Windows.Forms.Padding(4)
Me.btn_LoadCodes.Name = "btn_LoadCodes"
Me.btn_LoadCodes.Size = New System.Drawing.Size(187, 38)
Me.btn_LoadCodes.TabIndex = 10
Me.btn_LoadCodes.Text = "Load 'em up"
Me.btn_LoadCodes.UseVisualStyleBackColor = False
'
'btn_BypassView
'
Me.btn_BypassView.Enabled = False
Me.btn_BypassView.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.btn_BypassView.Location = New System.Drawing.Point(1033, 631)
Me.btn_BypassView.Margin = New System.Windows.Forms.Padding(4)
Me.btn_BypassView.Name = "btn_BypassView"
Me.btn_BypassView.Size = New System.Drawing.Size(175, 71)
Me.btn_BypassView.TabIndex = 11
Me.btn_BypassView.Text = "Import and Map (skip view)"
Me.btn_BypassView.UseVisualStyleBackColor = True
'
'lbl_queryrunning
'
Me.lbl_queryrunning.AutoSize = True
Me.lbl_queryrunning.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.lbl_queryrunning.Location = New System.Drawing.Point(25, 604)
Me.lbl_queryrunning.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
Me.lbl_queryrunning.Name = "lbl_queryrunning"
Me.lbl_queryrunning.Size = New System.Drawing.Size(71, 25)
Me.lbl_queryrunning.TabIndex = 12
Me.lbl_queryrunning.Text = "Label1"
'
'ck_Bonus
'
Me.ck_Bonus.AutoSize = True
Me.ck_Bonus.Enabled = False
Me.ck_Bonus.Location = New System.Drawing.Point(594, 23)
Me.ck_Bonus.Margin = New System.Windows.Forms.Padding(4)
Me.ck_Bonus.Name = "ck_Bonus"
Me.ck_Bonus.Size = New System.Drawing.Size(114, 21)
Me.ck_Bonus.TabIndex = 13
Me.ck_Bonus.Text = "Bonus Codes"
Me.ck_Bonus.UseVisualStyleBackColor = True
Me.ck_Bonus.Visible = False
'
'ck_Unmarked
'
Me.ck_Unmarked.AutoSize = True
Me.ck_Unmarked.Enabled = False
Me.ck_Unmarked.Location = New System.Drawing.Point(729, 23)
Me.ck_Unmarked.Margin = New System.Windows.Forms.Padding(4)
Me.ck_Unmarked.Name = "ck_Unmarked"
Me.ck_Unmarked.Size = New System.Drawing.Size(179, 21)
Me.ck_Unmarked.TabIndex = 14
Me.ck_Unmarked.Text = "Include UM (OOB ELW)"
Me.ck_Unmarked.UseVisualStyleBackColor = True
Me.ck_Unmarked.Visible = False
'
'form_ViewCodes
'
Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
Me.ClientSize = New System.Drawing.Size(1459, 758)
Me.Controls.Add(Me.ck_Unmarked)
Me.Controls.Add(Me.ck_Bonus)
Me.Controls.Add(Me.lbl_queryrunning)
Me.Controls.Add(Me.btn_BypassView)
Me.Controls.Add(Me.btn_LoadCodes)
Me.Controls.Add(Me.dom_BroodYearChoose)
Me.Controls.Add(Me.pb_Loading)
Me.Controls.Add(Me.btn_LoadTags)
Me.Controls.Add(Me.btn_Return1)
Me.Controls.Add(Me.btn_SelectUnselect)
Me.Controls.Add(Me.grd_CodeView)
Me.Controls.Add(Me.lbl_CWTdb2)
Me.Margin = New System.Windows.Forms.Padding(4)
Me.Name = "form_ViewCodes"
Me.Text = "FRAM Builder: View Tags"
CType(Me.grd_CodeView, System.ComponentModel.ISupportInitialize).EndInit()
Me.ResumeLayout(False)
Me.PerformLayout()

End Sub
    Friend WithEvents lbl_CWTdb2 As System.Windows.Forms.Label
    Friend WithEvents btn_SelectUnselect As System.Windows.Forms.Button
    Friend WithEvents btn_Return1 As System.Windows.Forms.Button
    Friend WithEvents btn_LoadTags As System.Windows.Forms.Button
    Friend WithEvents tip_SelectUnselect As System.Windows.Forms.ToolTip
    Public WithEvents grd_CodeView As System.Windows.Forms.DataGridView
    Friend WithEvents pb_Loading As System.Windows.Forms.ProgressBar
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents dom_BroodYearChoose As System.Windows.Forms.DomainUpDown
   Friend WithEvents btn_LoadCodes As System.Windows.Forms.Button
   Friend WithEvents btn_BypassView As System.Windows.Forms.Button
   Friend WithEvents lbl_queryrunning As System.Windows.Forms.Label
   Public WithEvents ck_Bonus As System.Windows.Forms.CheckBox
   Public WithEvents ck_Unmarked As System.Windows.Forms.CheckBox
End Class
